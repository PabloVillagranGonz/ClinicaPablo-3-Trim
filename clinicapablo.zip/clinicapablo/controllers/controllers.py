# -*- coding: utf-8 -*-
# from odoo import http


# class Clinicapablo(http.Controller):
#     @http.route('/clinicapablo/clinicapablo', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/clinicapablo/clinicapablo/objects', auth='public')
#     def list(self, **kw):
#         return http.request.render('clinicapablo.listing', {
#             'root': '/clinicapablo/clinicapablo',
#             'objects': http.request.env['clinicapablo.clinicapablo'].search([]),
#         })

#     @http.route('/clinicapablo/clinicapablo/objects/<model("clinicapablo.clinicapablo"):obj>', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('clinicapablo.object', {
#             'object': obj
#         })
