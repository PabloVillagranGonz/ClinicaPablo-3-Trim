# -*- coding: utf-8 -*-

from odoo import models, fields

class Client(models.Model):
    _name = 'clinicapablo.client'
    _description = 'Client'

    name = fields.Char(string="Nombre", required=True, help="Introduzca el nombre")
    last_name = fields.Char(string="Apellidos", required=True, help="Introduzca los apellidos")
    birth_date = fields.Date(string="Fecha nacimiento")
    phone = fields.Char(string="Número de teléfono")
    email = fields.Char(string="Email")
    address = fields.Text(string="Dirección")

    # Relacion One2many con el modelo 'clinicapablo.register'  
    register_id = fields.One2many(comodel_name="clinicapablo.register", inverse_name="client_id", string="Registro")
    
    # Metodo para personalizar el nombre en listas y relaciones  
    def name_get(self):
        result = []
        for record in self:
            name = f"Clinic{record.name or ''}"
            result.append((record.id, name))
        return result
