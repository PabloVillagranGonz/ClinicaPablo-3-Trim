from odoo import models, fields

class Session(models.Model):
    _name = 'clinicapablo.session'
    _description = 'clinicapablo.session'

    name = fields.Char(string="Nombre", required=True, help="Introduzca el nombre")
    address = fields.Text(string="Descripción")
    date = fields.Datetime(string="Fecha", required=True)

    # Relacion Many2one con el modelo 'clinicapablo.treatment'   
    treatment_id = fields.Many2one("clinicapablo.treatment", string="Tratamiento", required=True, ondelete="cascade")

    # Relacion Many2many con el modelo 'clinicapablo.technique'   
    technique_id = fields.Many2many("clinicapablo.technique", string="Técnicas Usadas")

    # Relacion Many2one con el modelo 'clinicapablo.professional'   
    professional_id = fields.Many2one("clinicapablo.professional", string="Profesional", ondelete="cascade")

    # Metodo para personalizar el nombre en listas y relaciones  
    def name_get(self):
        result = []
        for record in self:
            name = f"Clinic {record.name or ''}"
            result.append((record.id, name))
        return result
