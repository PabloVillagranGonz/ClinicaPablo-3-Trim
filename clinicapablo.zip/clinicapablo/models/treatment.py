# -*- coding: utf-8 -*-

import logging
from odoo import models, fields, api
from datetime import datetime
from odoo.exceptions import UserError

class Treatment(models.Model):
    _name = 'clinicapablo.treatment'
    _description = 'clinicapablo.treatment'

    name = fields.Char(string = "Nombre", required = True, help="Introduzca el nombre")
    description = fields.Text(string="Descripcion")
    date_start = fields.Datetime(string="Fecha de inicio")
    date_end = fields.Datetime(string="Fecha de fin")

    # Relacion Many2one con el modelo 'clinicapablo.register'   
    register_id = fields.Many2one("clinicapablo.register", string="Registro", required=True, ondelete="cascade")

    # Relacion One2many con el modelo 'clinicapablo.treatment'   
    session_id = fields.One2many(string="Sesiones",comodel_name="clinicapablo.session",inverse_name="treatment_id")

    # Relacion Many2one con el modelo 'clinicapablo.professional'   
    professional_id = fields.Many2one('clinicapablo.professional', string='Profesional', required=True)

    # Metodo para personalizar el nombre en listas y relaciones  
    def name_get(self):
        result = []
        for record in self:
            name = f"{record.name} - {record.register_id.name}"
            result.append((record.id, name))
        return result

    # Validacion de fechas: la fecha de inicio debe ser anterior a la fecha de fin
    @api.constrains('date_start', 'date_end')
    def _check_dates(self):
        for record in self:
            if record.date_start and record.date_end:
                if record.date_start >= record.date_end:
                    raise ValueError("La fecha de inicio debe ser anterior a la fecha de fin.")


    # Creacion de un boton "Crear Factura" y que automaticamente generara una factura en borrado para el cliente correspondiente
    def action_create_invoice(self):
            for record in self:
                client = record.register_id.client_id
                if not client:
                    raise UserError("El tratamiento no tiene un cliente asignado.")
                
                invoice = self.env['account.move'].create({
                    'move_type': 'out_invoice',
                    'partner_id': client.id,
                    'invoice_line_ids': [(0, 0, {
                        'name': record.name,
                        'quantity': 1,
                        'price_unit': 50.0,
                    })]
                })

                return {
                    'type': 'ir.actions.act_window',
                    'res_model': 'account.move',
                    'view_mode': 'form',
                    'res_id': invoice.id,
                }