from odoo import models, fields

class TreatmentInherited(models.Model):
    _inherit = 'clinicapablo.treatment'

    duration_minutes = fields.Integer(string="Duración (minutos)")
