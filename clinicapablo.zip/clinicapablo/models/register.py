# -*- coding: utf-8 -*-

from odoo import models, fields
from datetime import datetime

class Register(models.Model):
    _name = 'clinicapablo.register'
    _description = 'clinicapablo.register'

    name = fields.Char(string = "Nombre", required = True, help="Introduzca el nombre")
    address = fields.Text(string = "Descripcion")

    # Relacion Many2one con el modelo 'clinicapablo.client'   
    client_id = fields.Many2one("clinicapablo.client", string="Cliente", required=True, ondelete="cascade")

    # Relacion One2many con el modelo 'clinicapablo.register'   
    treatment_id = fields.One2many(string="Tratamiento", comodel_name="clinicapablo.treatment", inverse_name="register_id")
    
    # Metodo para personalizar el nombre en listas y relaciones  
    def name_get(self):
        result = []
        for record in self:
            name = f"Clinic {record.name or ''}"
            result.append((record.id, name))
        return result

