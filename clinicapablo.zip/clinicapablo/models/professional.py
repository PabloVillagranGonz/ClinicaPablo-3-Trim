from odoo import models, fields, api

class Professional(models.Model):
    _name = 'clinicapablo.professional'
    _description = 'clinicapablo.professional'

    name = fields.Char(string="Nombre", required=True, help="Introduzca el nombre")
    last_name = fields.Char(string="Apellidos", required=True, help="Introduzca los apellidos")

    # Tipo de especializacion del profesional
    type = fields.Selection([
        ('muscular', 'Muscular'),
        ('deportivo', 'Deportivo'),
        ('geriatrico', 'Geriátrico'),
        ('pediatrico', 'Pediátrico')
    ], string='Tipo', required=True)

    phone = fields.Char(string="Teléfono")
    email = fields.Char(string="Email")

    # Relacion One2many con el modelo 'clinicapablo.treatment'   
    treatment_id = fields.One2many('clinicapablo.treatment', 'professional_id', string='Tratamientos Asignados')

    session_summary = fields.One2many(
        'clinicapablo.session', 'professional_id',
        string='Sesiones Asignadas',
        compute='_compute_sessions'
    )

    # Metodo para calcular las sesiones asignadas al profesional  
    @api.depends('treatment_id')
    def _compute_sessions(self):
        for record in self:
            record.session_summary = self.env['clinicapablo.session'].search([('professional_id', '=', record.id)])
    
    # Metodo para personalizar el nombre en listas y relaciones  
    def name_get(self):
        result = []
        for record in self:
            name = f"Clinic {record.name or ''}"
            result.append((record.id, name))
        return result
