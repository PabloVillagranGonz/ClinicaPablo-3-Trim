# -*- coding: utf-8 -*-

from odoo import models, fields
from datetime import datetime

class Technique(models.Model):
     _name = 'clinicapablo.technique'
     _description = 'clinicapablo.technique'

     name = fields.Char(string = "Nombre", required = True, help="Introduzca el nombre")
     address = fields.Text(string = "Descripcion")

    # Relacion Many2many con el modelo 'clinicapablo.session'   
     session_id = fields.Many2many(
          comodel_name="clinicapablo.session",
          string="Sesiones donde se usa"
     )
    
    # Metodo para personalizar el nombre en listas y relaciones  
     def name_get(self):
        result = []
        for record in self:
            name = f"Clinic {record.name or ''}"
            result.append((record.id, name))
        return result
